//
//  ViewController.swift
//  LPS2020
//
//  Created by Juan Soler Marquez on 30/12/2019.
//  Copyright © 2019 ual. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

